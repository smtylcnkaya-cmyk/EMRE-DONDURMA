function toggleMenu(id) {
  const section = document.getElementById(id);
  section.classList.toggle('show');
}

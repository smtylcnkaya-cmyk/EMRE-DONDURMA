 ├── menu.html
 ├── menu.css
 ├── menu.js
 └── menu.json
